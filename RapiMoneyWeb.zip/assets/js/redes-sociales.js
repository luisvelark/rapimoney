// let face = document.getElementById("id-face");

// face.addEventListener("click", (e) => {
//   e.preventDefault();
//   console.log("ya no hace el enlace");

//   const facebookId = "fb://page/117541069901209";
//   const urlPage = "http://www.facebook.com/mypage";

//   try {
//     startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(facebookId)));
//   } catch (error) {
//     console.error("Aplicación no instalada.");
//     //Abre url de pagina.
//     startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(urlPage)));
//   }
// });
